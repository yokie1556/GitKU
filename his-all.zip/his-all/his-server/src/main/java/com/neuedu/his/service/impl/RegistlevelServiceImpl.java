package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Registlevel;
import com.neuedu.his.service.RegistlevelService;
import com.neuedu.his.mapper.RegistlevelMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【registlevel】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class RegistlevelServiceImpl extends ServiceImpl<RegistlevelMapper, Registlevel>
    implements RegistlevelService{

}




