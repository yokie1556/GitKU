package com.neuedu.his.service;

import com.neuedu.his.po.Checkdetailed;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author Superior
* @description 针对表【checkdetailed】的数据库操作Service
* @createDate 2025-07-08 10:31:26
*/
public interface CheckdetailedService extends IService<Checkdetailed> {

}
