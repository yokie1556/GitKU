package com.neuedu.his.mapper;

import com.neuedu.his.po.Drugs;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class DrugsMapperTest {
    @Autowired
    private DrugsMapper drugsMapper;


    @Test
    public void test(){
        List<Drugs> drugs = drugsMapper.selectList(null);
        drugs.forEach(System.out::println);
    }

}