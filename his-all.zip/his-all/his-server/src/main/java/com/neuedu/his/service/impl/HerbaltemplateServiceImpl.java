package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Herbaltemplate;
import com.neuedu.his.service.HerbaltemplateService;
import com.neuedu.his.mapper.HerbaltemplateMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【herbaltemplate】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class HerbaltemplateServiceImpl extends ServiceImpl<HerbaltemplateMapper, Herbaltemplate>
    implements HerbaltemplateService{

}




