<script setup>
// 组件
    import  NavMenu  from '../components/NavMenu.vue'
    import { useCounterStore } from "@/stores/counter.js";
    const counter = useCounterStore();
    import {onMounted, ref} from 'vue'
    const username = ref('')
    onMounted(() => {
    username.value = counter.vo_user.value.username
    console.log("username",username.value)
})

</script>


<template>
    <el-container>
      <el-header class="header">
        <el-row>
          <el-col :span="16">东软云医院</el-col>
          <el-col :span="8">欢迎{{username}}
            <el-button
              type="danger"
              link
            >，退出登录</el-button>
          </el-col>
        </el-row>
      </el-header>
      <el-container  class="container">
        <el-aside width="200px" class="aside">
              <NavMenu></NavMenu>
        </el-aside>
        <el-main class="content">
           <RouterView></RouterView>
        </el-main>
      </el-container>
    </el-container>


</template>


<style>

    /* 样式 */
.header{
    background-color: #C6E2FF;
}



/* container */
.container{
    height:  calc( 100vh - 60px);
}



.aside{
    background-color: #D9ECFF;
}

.content{

    background-color: #ECF5FF;

}


</style>