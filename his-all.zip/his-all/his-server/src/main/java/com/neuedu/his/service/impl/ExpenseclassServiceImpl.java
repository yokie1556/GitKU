package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Expenseclass;
import com.neuedu.his.service.ExpenseclassService;
import com.neuedu.his.mapper.ExpenseclassMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【expenseclass】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class ExpenseclassServiceImpl extends ServiceImpl<ExpenseclassMapper, Expenseclass>
    implements ExpenseclassService{

}




