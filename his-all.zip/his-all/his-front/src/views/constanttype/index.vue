<template>
  <el-form :model="form" label-width="auto" style="max-width: 600px" :inline="true">
    <el-form-item>
      <el-button type="primary" @click="toAdd">添加</el-button>
    </el-form-item>
  </el-form>

  <div>
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="constanttypecode" label="常数类别编码" width="180"/>
      <el-table-column prop="constanttypename" label="常数类别名称" width="180"/>
      <el-table-column label="操作">
        <template #default="slot">
          <el-button link type="primary" size="small" @click="toEdit(slot.row)">编辑</el-button>
          <el-button link type="primary" size="small" @click="toDelete([slot.row.id])">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>

  <!-- 添加/编辑表单 dialogFormVisible 表示是否显示，  boolean   -->
  <el-dialog v-model="editDialogFormVisible" title="添加/编辑常数类别" width="500">
    <el-form :model="editForm" label-width="auto">
      <el-form-item label="常数类别编码">
        <el-input v-model="editForm.constanttypecode"/>
      </el-form-item>
      <el-form-item label="常数类别名称">
        <el-input v-model="editForm.constanttypename"/>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="save">保存</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { ElNotification } from 'element-plus'
import service from '@/utils/request'

let form = ref({})
let editForm = ref({
  id: null,
  constanttypecode: '',
  constanttypename: ''
})
// 是否显示 dialog
let editDialogFormVisible = ref(false)

// 提交数据
function onSubmit() {
  console.log("form", form.value)
}

// 表格的数据
let tableData = ref([])

function toAdd() {
  editForm.value = {
    id: null,
    constanttypecode: '',
    constanttypename: ''
  }
  editDialogFormVisible.value = true
}

function toEdit(row) {
  editForm.value = { ...row }
  editDialogFormVisible.value = true
}

function toDelete(ids) {
  service.post("/constanttype/delete", ids).then(
      res => {
        if (res.data) {
          ElNotification({
            title: '提示',
            message: '删除成功！',
            type: 'success'
          })
          listData()
        } else {
          ElNotification({
            title: '提示',
            message: '删除失败！',
            type: 'error'
          })
        }
      }
  )
}

function save() {
  let url = editForm.value.id ? "/constanttype/update" : "/constanttype/add"
  service.post(url, editForm.value).then(
      res => {
        console.log(res.data)
        editDialogFormVisible.value = false
        if (res.data) {
          ElNotification({
            title: '提示',
            message: editForm.value.id ? '编辑成功！' : '保存成功！',
            type: 'success'
          })
          listData()
        } else {
          ElNotification({
            title: '提示',
            message: editForm.value.id ? '编辑失败！' : '保存失败！',
            type: 'error'
          })
        }
      }
  )
}

function listData() {
  service.get("/constanttype/list").then(
      res => {
        console.log(res)
        tableData.value = res.data
      }
  )
}

onMounted(() => {
  listData()
})
</script>