package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Herbaldetailed;
import com.neuedu.his.service.HerbaldetailedService;
import com.neuedu.his.mapper.HerbaldetailedMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【herbaldetailed】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class HerbaldetailedServiceImpl extends ServiceImpl<HerbaldetailedMapper, Herbaldetailed>
    implements HerbaldetailedService{

}




