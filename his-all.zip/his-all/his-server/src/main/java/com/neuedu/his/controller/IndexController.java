package com.neuedu.his.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class IndexController {

    @RequestMapping("/index")
    public String index(){
        return "success";
    }

    @RequestMapping("/json")
    public List json(){
        List list = new ArrayList();
        for(int i = 0;i < 10;i ++){
            Map map = new HashMap();
            map.put("id", 1);
            map.put("name", "name"+i);
            map.put("address", "address"+i);
            list.add(map);
        }
        return list;
    }
}
