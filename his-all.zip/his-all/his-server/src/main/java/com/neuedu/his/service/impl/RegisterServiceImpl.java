package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Register;
import com.neuedu.his.service.RegisterService;
import com.neuedu.his.mapper.RegisterMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【register】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class RegisterServiceImpl extends ServiceImpl<RegisterMapper, Register>
    implements RegisterService{

}




