package com.neuedu.his.mapper;

import com.neuedu.his.po.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Superior
* @description 针对表【user】的数据库操作Mapper
* @createDate 2025-06-25 18:42:33
* @Entity com.neuedu.his.po.User
*/
public interface UserMapper extends BaseMapper<User> {

}




