package com.neuedu.his.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.neuedu.his.po.Constantitem;
import com.neuedu.his.po.User;
import com.neuedu.his.service.ConstantitemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/constantitem")
public class ConstantItemController {

    @Autowired
    ConstantitemService service;

    @RequestMapping("/list")
    public List<Constantitem> list(){
        return  service.list();
    }

    @RequestMapping("/getbytypeid")
    public List<Constantitem> getbytypeid(@RequestBody Map<String,String>id){
        LambdaQueryWrapper<Constantitem> queryWrapper = new LambdaQueryWrapper<>();
        System.out.println(id.get("id"));
        queryWrapper.eq(Constantitem::getConstanttypeid,Integer.parseInt(id.get("id")));
        return service.list(queryWrapper);
    }

    @RequestMapping("/getbytypeid2")
    public List<Constantitem> getbytypeid2(@RequestParam Integer id){
        System.out.println("getbytypeid2   id="+id);
        QueryWrapper<Constantitem> qw = new QueryWrapper<>();
        qw.eq("constanttypeid",id);
        return service.list(qw);
    }
    @RequestMapping("/add")
    public boolean add(@RequestBody Constantitem constantitem){
        return service.save(constantitem);
    }
    @RequestMapping("/delete")
    public boolean delete(@RequestBody List<Integer> ids){
        return service.removeByIds(ids);
    }
    @RequestMapping("/update")
    public boolean update(@RequestBody Constantitem constantitem){
        return service.updateById(constantitem);
    }
}