package com.neuedu.his.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.neuedu.his.po.Medicalrecord;
import com.neuedu.his.service.MedicalrecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/medicalrecord")
public class medicalRecordController {

    @Autowired
    private MedicalrecordService medicalrecordService;

    /**
     * 创建病历
     * @param medicalrecord 病历实体
     * @return 创建结果
     */
    @PostMapping
    public boolean createMedicalrecord(@RequestBody Medicalrecord medicalrecord) {
        return medicalrecordService.save(medicalrecord);
    }

    /**
     * 根据 ID 查询病历
     * @param id 病历 ID
     * @return 病历实体
     */
    @GetMapping("/{id}")
    public Medicalrecord getMedicalrecordById(@PathVariable Integer id) {
        return medicalrecordService.getById(id);
    }

    /**
     * 查询所有病历
     * @return 病历列表
     */
    @GetMapping
    public List<Medicalrecord> getAllMedicalrecords() {
        return medicalrecordService.list();
    }

    /**
     * 分页查询病历
     * @param pageNum 页码
     * @param pageSize 每页数量
     * @return 分页结果
     */
    @GetMapping("/page")
    public Page<Medicalrecord> getMedicalrecordsByPage(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        Page<Medicalrecord> page = new Page<>(pageNum, pageSize);
        return medicalrecordService.page(page);
    }

    /**
     * 更新病历
     * @param medicalrecord 病历实体
     * @return 更新结果
     */
    @PutMapping
    public boolean updateMedicalrecord(@RequestBody Medicalrecord medicalrecord) {
        return medicalrecordService.updateById(medicalrecord);
    }

    /**
     * 根据 ID 删除病历
     * @param id 病历 ID
     * @return 删除结果
     */
    @DeleteMapping("/{id}")
    public boolean deleteMedicalrecordById(@PathVariable Integer id) {
        return medicalrecordService.removeById(id);
    }

    /**
     * 根据病历号查询病历
     * @param caseNumber 病历号
     * @return 病历列表
     */
    @GetMapping("/caseNumber/{caseNumber}")
    public List<Medicalrecord> getMedicalrecordsByCaseNumber(@PathVariable String caseNumber) {
        QueryWrapper<Medicalrecord> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("CaseNumber", caseNumber);
        return medicalrecordService.list(queryWrapper);
    }
}