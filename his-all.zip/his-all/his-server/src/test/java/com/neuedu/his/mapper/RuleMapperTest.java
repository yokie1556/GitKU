package com.neuedu.his.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.neuedu.his.po.Rule;
import com.neuedu.his.po.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class RuleMapperTest {

    @Autowired
    private RuleMapper ruleMapper;

    @Test
    public void test() {
        List<Rule> rules = ruleMapper.selectList(null);
        rules.forEach(System.out::println);
    }


    @Test
    public void test2() {
        //查询条件构造器
        LambdaQueryWrapper<Rule> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Rule::getId,1);
        // 查询结果
        // select * from Rule where  id = ?   Rulename like ?
        List<Rule> rules =ruleMapper.selectList(queryWrapper);
        rules.forEach(System.out::println);
    }

    @Test
    public void selectById() {
        System.out.println("查询特定一条");
        Long id = 1L;
        Rule rule = ruleMapper.selectById(id);
        System.out.println("rule = " + rule);
    }

    @Test
    public void insert() {
        Rule rule = new Rule();
        rule.setId(666);
        rule.setRulename("sss");
        rule.setDeptid(666);
        rule.setUserid(1);
        rule.setWeek("11111111111111");
        rule.setDelmark(1);
        int count = ruleMapper.insert(rule);
        System.out.println("count = " + count);
    }

    @Test
    public void updateById() {
        Long id = 666L;
        Rule rule = ruleMapper.selectById(id);
        rule.setRulename(rule.getRulename() + "123");
        // 全量字段更新
        int count = ruleMapper.updateById(rule);
        System.out.println("count = " + count);
    }


    @Test
    public void deleteById() {
        Long id = 666L;
        int count = ruleMapper.deleteById(id);
        System.out.println("count = " + count);
    }
}