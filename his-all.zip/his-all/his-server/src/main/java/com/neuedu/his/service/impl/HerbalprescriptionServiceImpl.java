package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Herbalprescription;
import com.neuedu.his.service.HerbalprescriptionService;
import com.neuedu.his.mapper.HerbalprescriptionMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【herbalprescription】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class HerbalprescriptionServiceImpl extends ServiceImpl<HerbalprescriptionMapper, Herbalprescription>
    implements HerbalprescriptionService{

}




