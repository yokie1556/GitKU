package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Medicaldisease;
import com.neuedu.his.service.MedicaldiseaseService;
import com.neuedu.his.mapper.MedicaldiseaseMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【medicaldisease】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class MedicaldiseaseServiceImpl extends ServiceImpl<MedicaldiseaseMapper, Medicaldisease>
    implements MedicaldiseaseService{

}




