package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Medicalrecord;
import com.neuedu.his.service.MedicalrecordService;
import com.neuedu.his.mapper.MedicalrecordMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【medicalrecord】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class MedicalrecordServiceImpl extends ServiceImpl<MedicalrecordMapper, Medicalrecord>
    implements MedicalrecordService{

}




