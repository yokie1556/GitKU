<template>
  <el-form :model="form" label-width="auto" style="max-width: 600px" :inline="true">
    <el-form-item label="请选择常数类别">
      <el-select
          @change = "typeChange"
          v-model="selectType"
          placeholder="请选择常数类别..."
          size="large"
          style="width: 240px"
      >
        <el-option
            v-for="item in options"
            :key="item.id"
            :label="item.constanttypename"
            :value="item.id"
        />
      </el-select>
    </el-form-item>


    <el-form-item>
      <el-button type="primary" @click="toAdd">添加</el-button>
    </el-form-item>
  </el-form>

  <div>
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="constanttypeid" label="常数类别ID" width="180"/>
      <el-table-column prop="constantcode" label="常数项编码" width="180"/>
      <el-table-column prop="constantname" label="常数项名称"/>
      <el-table-column label="操作">
        <template #default="solt">
          <el-button link type="primary" size="small" @click="toEdit(solt.row)"> 编辑</el-button>
          <el-button link type="primary" size="small" @click="toDelete(solt.row.id)">删除</el-button>
        </template>

      </el-table-column>
    </el-table>
  </div>

  <!-- 添加表单 dialogFormVisible 表示是否显示，  boolean   -->
  <el-dialog v-model="editDialogFormVisible" title="用户编辑" width="500">
    <el-form :model="editForm" label-width="auto">
      <el-form-item label="常数类别ID">
        <el-input v-model="editForm.constanttypeid"/>
      </el-form-item>
      <el-form-item label="常数项编码">
        <el-input v-model="editForm.constantcode"/>
      </el-form-item>
      <el-form-item label="常数项名称">
        <el-input v-model="editForm.constantname"/>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="save">保存</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>


<script setup>
import {onMounted, onUnmounted, ref} from 'vue'
import {ElNotification} from 'element-plus'
import service from '@/utils/request'

let selectType = ref('')    //常数类别列表用户选择的typeid
let options = ref([])   //常数类别列表
let form = ref({});
//是否显示 dialog
let editDialogFormVisible = ref(false);

//提交数据 到
function onSubmit() {
  console.log("form", form.value);
}

//表格的数据
let tableData = ref([])

// 编辑表单数据
let editForm = ref({
  constanttypeid: '',
  constantcode: '',
  constantname: ''
})

function toAdd() {
  // 清空编辑表单数据
  editForm.value = {
    constanttypeid: '',
    constantcode: '',
    constantname: ''
  }
  editDialogFormVisible.value = true;
}

function typeChange(a){
  service.post("/constantitem/getbytypeid",{id:a}).then(
      res=>{
        tableData.value = res.data
      }
  )
}

function save() {
  // 判断是添加还是更新操作
  if (editForm.value.id) {
    // 更新操作
    service.post("/constantitem/update", editForm.value).then(
        res => {
          if (res) {
            ElNotification({
              title: '提示',
              message: '更新成功',
              type: 'success',
            })
            // 重新加载数据
            listData()
          } else {
            ElNotification({
              title: '提示',
              message: '更新失败',
              type: 'error',
            })
          }
          editDialogFormVisible.value = false;
        }
    )
  } else {
    // 添加操作
    service.post("/constantitem/add", editForm.value).then(
        res => {
          if (res) {
            ElNotification({
              title: '提示',
              message: '添加成功',
              type: 'success',
            })
            // 重新加载数据
            listData()
          } else {
            ElNotification({
              title: '提示',
              message: '添加失败',
              type: 'error',
            })
          }
          editDialogFormVisible.value = false;
        }
    )
  }
}

function listData(){
  service.get("/constantitem/list").then(
      res=>{
        tableData.value = res.data;
      }
  )
}

function toEdit(row) {
  // 将选中行的数据赋值给编辑表单
  editForm.value = {...row}
  editDialogFormVisible.value = true;
}

function toDelete(id) {
  service.post("/constantitem/delete", [id]).then(
      res => {
        if (res) {
          ElNotification({
            title: '提示',
            message: '删除成功',
            type: 'success',
          })
          // 重新加载数据
          listData()
        } else {
          ElNotification({
            title: '提示',
            message: '删除失败',
            type: 'error',
          })
        }
      }
  )
}

onMounted(() => {
  //加载常数项所有数据
  listData()

  //加载常数类别，提供给用户选择（下拉列别）
  service.get("/constanttype/list").then(
      res=>{
        options.value = res.data
        // selectType.value = 1
      }
  )
})
</script>