package com.neuedu.his.mapper;

import com.neuedu.his.po.Herbaldetailed;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Superior
* @description 针对表【herbaldetailed】的数据库操作Mapper
* @createDate 2025-06-25 18:42:33
* @Entity com.neuedu.his.po.Herbaldetailed
*/
public interface HerbaldetailedMapper extends BaseMapper<Herbaldetailed> {

}




