package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Fmeditem;
import com.neuedu.his.service.FmeditemService;
import com.neuedu.his.mapper.FmeditemMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【fmeditem】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class FmeditemServiceImpl extends ServiceImpl<FmeditemMapper, Fmeditem>
    implements FmeditemService{

}




