package com.neuedu.his;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HisServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
