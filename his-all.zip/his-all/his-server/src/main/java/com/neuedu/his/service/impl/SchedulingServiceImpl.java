package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Scheduling;
import com.neuedu.his.service.SchedulingService;
import com.neuedu.his.mapper.SchedulingMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【scheduling】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class SchedulingServiceImpl extends ServiceImpl<SchedulingMapper, Scheduling>
    implements SchedulingService{

}




