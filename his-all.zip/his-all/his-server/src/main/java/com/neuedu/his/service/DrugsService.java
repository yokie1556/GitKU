package com.neuedu.his.service;

import com.neuedu.his.po.Drugs;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author Superior
* @description 针对表【drugs】的数据库操作Service
* @createDate 2025-06-25 18:42:33
*/
public interface DrugsService extends IService<Drugs> {

}
