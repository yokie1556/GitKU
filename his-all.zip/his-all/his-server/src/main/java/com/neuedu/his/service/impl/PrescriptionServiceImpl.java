package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Prescription;
import com.neuedu.his.service.PrescriptionService;
import com.neuedu.his.mapper.PrescriptionMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【prescription】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class PrescriptionServiceImpl extends ServiceImpl<PrescriptionMapper, Prescription>
    implements PrescriptionService{

}




