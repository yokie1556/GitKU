package com.neuedu.his.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.neuedu.his.po.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class UserMapperTest {

    @Autowired
    private UserMapper userMapper;
    @Test
    public void test() {
        List<User> users = userMapper.selectList(null);
        users.forEach(System.out::println);
    }


    @Test
    public void test2() {
        //查询条件构造器
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getId,1);
        // 查询结果
        // select * from user where  id = ?   username like ?
        List<User> users = userMapper.selectList(queryWrapper);
        users.forEach(System.out::println);
    }

    @Test
    public void selectById() {
        System.out.println("查询特定一条");
        Long id = 1L;
        User user = userMapper.selectById(id);
        System.out.println("user = " + user);
    }

    @Test
    public void insert() {
        // 模拟从用户界面录入数据
        User user = new User();
        user.setUsername("MyBatis");
        user.setPassword("123456");
        user.setRealname("MyBatis");
        user.setDeptid(1);
        user.setDelmark(1);
        int count = userMapper.insert(user);
        System.out.println("count = " + count);
    }

    @Test
    public void updateById() {
        Long id = 13L;
        User user = userMapper.selectById(id);
        user.setPassword(user.getPassword() + "456");
        user.setRealname(user.getRealname() + "123");
        // 全量字段更新
        int count = userMapper.updateById(user);
        System.out.println("count = " + count);
    }


    @Test
    public void deleteById() {
        Long id = 13L;
        int count = userMapper.deleteById(id);
        System.out.println("count = " + count);
    }
}