package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Disease;
import com.neuedu.his.service.DiseaseService;
import com.neuedu.his.mapper.DiseaseMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【disease】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class DiseaseServiceImpl extends ServiceImpl<DiseaseMapper, Disease>
    implements DiseaseService{

}




