package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Checkrelation;
import com.neuedu.his.service.CheckrelationService;
import com.neuedu.his.mapper.CheckrelationMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【checkrelation】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class CheckrelationServiceImpl extends ServiceImpl<CheckrelationMapper, Checkrelation>
    implements CheckrelationService{

}




