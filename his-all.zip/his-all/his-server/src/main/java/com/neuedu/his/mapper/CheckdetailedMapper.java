package com.neuedu.his.mapper;

import com.neuedu.his.po.Checkdetailed;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Superior
* @description 针对表【checkdetailed】的数据库操作Mapper
* @createDate 2025-07-08 10:31:26
* @Entity com.neuedu.his.po.Checkdetailed
*/
public interface CheckdetailedMapper extends BaseMapper<Checkdetailed> {

}




