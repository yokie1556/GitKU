package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Drugs;
import com.neuedu.his.service.DrugsService;
import com.neuedu.his.mapper.DrugsMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【drugs】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class DrugsServiceImpl extends ServiceImpl<DrugsMapper, Drugs>
    implements DrugsService{

}




