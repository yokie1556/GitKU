package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Rule;
import com.neuedu.his.service.RuleService;
import com.neuedu.his.mapper.RuleMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【rule】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class RuleServiceImpl extends ServiceImpl<RuleMapper, Rule>
    implements RuleService{

}




