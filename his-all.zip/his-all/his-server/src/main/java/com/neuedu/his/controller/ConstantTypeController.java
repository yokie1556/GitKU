package com.neuedu.his.controller;

import com.neuedu.his.po.Constanttype;
import com.neuedu.his.service.ConstanttypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/constanttype")
public class ConstantTypeController {

    @Autowired
    private ConstanttypeService constanttypeService;

    @RequestMapping("/list")
    public List<Constanttype> list(){
        return constanttypeService.list();
    }

    @RequestMapping("/add")
    public boolean add(@RequestBody Constanttype constanttype){
        return constanttypeService.save(constanttype);
    }

    @RequestMapping("/delete")
    public boolean delete(@RequestBody List<Integer> ids){
        return constanttypeService.removeByIds(ids);
    }

    @RequestMapping("/update")
    public boolean update(@RequestBody Constanttype constanttype){
        return constanttypeService.updateById(constanttype);
    }

    @RequestMapping("/getById")
    public Constanttype getById(@RequestBody Integer id){
        return constanttypeService.getById(id);
    }
}