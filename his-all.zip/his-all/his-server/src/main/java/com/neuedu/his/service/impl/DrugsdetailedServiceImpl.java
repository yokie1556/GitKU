package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Drugsdetailed;
import com.neuedu.his.service.DrugsdetailedService;
import com.neuedu.his.mapper.DrugsdetailedMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【drugsdetailed】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class DrugsdetailedServiceImpl extends ServiceImpl<DrugsdetailedMapper, Drugsdetailed>
    implements DrugsdetailedService{

}




