package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Constantitem;
import com.neuedu.his.service.ConstantitemService;
import com.neuedu.his.mapper.ConstantitemMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【constantitem】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class ConstantitemServiceImpl extends ServiceImpl<ConstantitemMapper, Constantitem>
    implements ConstantitemService{

}




