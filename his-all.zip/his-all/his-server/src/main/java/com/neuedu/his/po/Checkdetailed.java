package com.neuedu.his.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * @TableName checkdetailed
 */
@TableName(value ="checkdetailed")
public class Checkdetailed {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 
     */
    private Integer checkappid;

    /**
     * 
     */
    private Integer checkprojid;

    /**
     * 
     */
    private Integer deptid;

    /**
     * 
     */
    private Date creationtime;

    /**
     * 
     */
    private String position;

    /**
     * 
     */
    private Integer state;

    /**
     * 
     */
    private BigDecimal price;

    /**
     * 
     */
    private Integer identfication;

    /**
     * 
     */
    private Date inspecttime;

    /**
     * 
     */
    private String result;

    /**
     * 
     */
    private Date resulttime;

    /**
     * 
     */
    private Integer userid2;

    /**
     * 
     */
    private Integer userid;

    /**
     * 
     */
    private Integer delmark;

    /**
     * 
     */
    public Integer getId() {
        return id;
    }

    /**
     * 
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 
     */
    public Integer getCheckappid() {
        return checkappid;
    }

    /**
     * 
     */
    public void setCheckappid(Integer checkappid) {
        this.checkappid = checkappid;
    }

    /**
     * 
     */
    public Integer getCheckprojid() {
        return checkprojid;
    }

    /**
     * 
     */
    public void setCheckprojid(Integer checkprojid) {
        this.checkprojid = checkprojid;
    }

    /**
     * 
     */
    public Integer getDeptid() {
        return deptid;
    }

    /**
     * 
     */
    public void setDeptid(Integer deptid) {
        this.deptid = deptid;
    }

    /**
     * 
     */
    public Date getCreationtime() {
        return creationtime;
    }

    /**
     * 
     */
    public void setCreationtime(Date creationtime) {
        this.creationtime = creationtime;
    }

    /**
     * 
     */
    public String getPosition() {
        return position;
    }

    /**
     * 
     */
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * 
     */
    public Integer getState() {
        return state;
    }

    /**
     * 
     */
    public void setState(Integer state) {
        this.state = state;
    }

    /**
     * 
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * 
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * 
     */
    public Integer getIdentfication() {
        return identfication;
    }

    /**
     * 
     */
    public void setIdentfication(Integer identfication) {
        this.identfication = identfication;
    }

    /**
     * 
     */
    public Date getInspecttime() {
        return inspecttime;
    }

    /**
     * 
     */
    public void setInspecttime(Date inspecttime) {
        this.inspecttime = inspecttime;
    }

    /**
     * 
     */
    public String getResult() {
        return result;
    }

    /**
     * 
     */
    public void setResult(String result) {
        this.result = result;
    }

    /**
     * 
     */
    public Date getResulttime() {
        return resulttime;
    }

    /**
     * 
     */
    public void setResulttime(Date resulttime) {
        this.resulttime = resulttime;
    }

    /**
     * 
     */
    public Integer getUserid2() {
        return userid2;
    }

    /**
     * 
     */
    public void setUserid2(Integer userid2) {
        this.userid2 = userid2;
    }

    /**
     * 
     */
    public Integer getUserid() {
        return userid;
    }

    /**
     * 
     */
    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    /**
     * 
     */
    public Integer getDelmark() {
        return delmark;
    }

    /**
     * 
     */
    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Checkdetailed other = (Checkdetailed) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getCheckappid() == null ? other.getCheckappid() == null : this.getCheckappid().equals(other.getCheckappid()))
            && (this.getCheckprojid() == null ? other.getCheckprojid() == null : this.getCheckprojid().equals(other.getCheckprojid()))
            && (this.getDeptid() == null ? other.getDeptid() == null : this.getDeptid().equals(other.getDeptid()))
            && (this.getCreationtime() == null ? other.getCreationtime() == null : this.getCreationtime().equals(other.getCreationtime()))
            && (this.getPosition() == null ? other.getPosition() == null : this.getPosition().equals(other.getPosition()))
            && (this.getState() == null ? other.getState() == null : this.getState().equals(other.getState()))
            && (this.getPrice() == null ? other.getPrice() == null : this.getPrice().equals(other.getPrice()))
            && (this.getIdentfication() == null ? other.getIdentfication() == null : this.getIdentfication().equals(other.getIdentfication()))
            && (this.getInspecttime() == null ? other.getInspecttime() == null : this.getInspecttime().equals(other.getInspecttime()))
            && (this.getResult() == null ? other.getResult() == null : this.getResult().equals(other.getResult()))
            && (this.getResulttime() == null ? other.getResulttime() == null : this.getResulttime().equals(other.getResulttime()))
            && (this.getUserid2() == null ? other.getUserid2() == null : this.getUserid2().equals(other.getUserid2()))
            && (this.getUserid() == null ? other.getUserid() == null : this.getUserid().equals(other.getUserid()))
            && (this.getDelmark() == null ? other.getDelmark() == null : this.getDelmark().equals(other.getDelmark()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getCheckappid() == null) ? 0 : getCheckappid().hashCode());
        result = prime * result + ((getCheckprojid() == null) ? 0 : getCheckprojid().hashCode());
        result = prime * result + ((getDeptid() == null) ? 0 : getDeptid().hashCode());
        result = prime * result + ((getCreationtime() == null) ? 0 : getCreationtime().hashCode());
        result = prime * result + ((getPosition() == null) ? 0 : getPosition().hashCode());
        result = prime * result + ((getState() == null) ? 0 : getState().hashCode());
        result = prime * result + ((getPrice() == null) ? 0 : getPrice().hashCode());
        result = prime * result + ((getIdentfication() == null) ? 0 : getIdentfication().hashCode());
        result = prime * result + ((getInspecttime() == null) ? 0 : getInspecttime().hashCode());
        result = prime * result + ((getResult() == null) ? 0 : getResult().hashCode());
        result = prime * result + ((getResulttime() == null) ? 0 : getResulttime().hashCode());
        result = prime * result + ((getUserid2() == null) ? 0 : getUserid2().hashCode());
        result = prime * result + ((getUserid() == null) ? 0 : getUserid().hashCode());
        result = prime * result + ((getDelmark() == null) ? 0 : getDelmark().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", checkappid=").append(checkappid);
        sb.append(", checkprojid=").append(checkprojid);
        sb.append(", deptid=").append(deptid);
        sb.append(", creationtime=").append(creationtime);
        sb.append(", position=").append(position);
        sb.append(", state=").append(state);
        sb.append(", price=").append(price);
        sb.append(", identfication=").append(identfication);
        sb.append(", inspecttime=").append(inspecttime);
        sb.append(", result=").append(result);
        sb.append(", resulttime=").append(resulttime);
        sb.append(", userid2=").append(userid2);
        sb.append(", userid=").append(userid);
        sb.append(", delmark=").append(delmark);
        sb.append("]");
        return sb.toString();
    }
}