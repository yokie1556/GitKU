package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Department;
import com.neuedu.his.service.DepartmentService;
import com.neuedu.his.mapper.DepartmentMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【department】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class DepartmentServiceImpl extends ServiceImpl<DepartmentMapper, Department>
    implements DepartmentService{

}




