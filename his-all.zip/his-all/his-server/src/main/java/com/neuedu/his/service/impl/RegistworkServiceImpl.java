package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Registwork;
import com.neuedu.his.service.RegistworkService;
import com.neuedu.his.mapper.RegistworkMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【registwork】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class RegistworkServiceImpl extends ServiceImpl<RegistworkMapper, Registwork>
    implements RegistworkService{

}




