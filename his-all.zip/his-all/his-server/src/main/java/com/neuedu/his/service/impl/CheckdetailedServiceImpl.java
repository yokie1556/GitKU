package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Checkdetailed;
import com.neuedu.his.service.CheckdetailedService;
import com.neuedu.his.mapper.CheckdetailedMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【checkdetailed】的数据库操作Service实现
* @createDate 2025-07-08 10:31:26
*/
@Service
public class CheckdetailedServiceImpl extends ServiceImpl<CheckdetailedMapper, Checkdetailed>
    implements CheckdetailedService{

}




