<template>
  <div class="p-4">
    <!-- 搜索区 -->
    <div class="mb-4">
      <el-input v-model="search.medicalId" placeholder="病历号" style="width: 180px" />
      <el-input v-model="search.patientName" placeholder="患者姓名" style="width: 180px" />
      <el-select v-model="search.status" placeholder="申请状态" style="width: 180px">
        <el-option label="全部" value="" />
        <el-option label="待执行" value="1" />
        <el-option label="已执行" value="2" />
      </el-select>
      <el-button type="primary" @click="fetchList">搜索</el-button>
    </div>

    <!-- 列表区 -->
    <el-table :data="checkList" border @row-click="viewDetail">
      <el-table-column prop="medicalId" label="病历号" width="120" />
      <el-table-column prop="patientName" label="患者姓名" width="100" />
      <el-table-column prop="gender" label="性别" width="60" />
      <el-table-column prop="age" label="年龄" width="60" />
      <el-table-column prop="checkItemName" label="检验项目" min-width="150" />
      <el-table-column prop="applyTime" label="申请时间" width="180" />
      <el-table-column prop="statusText" label="状态" width="100" />
      <el-table-column label="操作" width="100">
        <el-button type="primary" size="small" @click.stop="executeCheck"
                   :disabled="row.status !== 1">执行</el-button>
      </el-table-column>
    </el-table>

    <!-- 详情对话框 -->
    <el-dialog :visible.sync="detailVisible" title="检验详情" width="700px">
      <div class="p-4">
        <div class="grid grid-cols-2 gap-4 mb-4">
          <div><span class="text-gray-500">病历号：</span>{{ detail.medicalId }}</div>
          <div><span class="text-gray-500">患者姓名：</span>{{ detail.patientName }}</div>
          <div><span class="text-gray-500">性别/年龄：</span>{{ detail.gender }}/{{ detail.age }}</div>
          <div><span class="text-gray-500">申请科室：</span>{{ detail.departmentName }}</div>
          <div><span class="text-gray-500">申请医生：</span>{{ detail.doctorName }}</div>
          <div><span class="text-gray-500">申请时间：</span>{{ detail.applyTime }}</div>
        </div>
        <div class="mb-4"><span class="text-gray-500">临床诊断：</span>{{ detail.diagnosis }}</div>
        <div v-if="detail.status === 2" class="mb-4"><span class="text-gray-500">检验结果：</span>{{ detail.result }}</div>
      </div>
      <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
        <el-button type="primary" @click="executeCheck" v-if="detail.status === 1">执行检验</el-button>
      </template>
    </el-dialog>

    <!-- 执行检验对话框 -->
    <el-dialog :visible.sync="executeVisible" title="执行检验" width="700px">
      <el-form :model="executeForm" label-width="120px">
        <el-form-item label="检验项目">
          <el-input v-model="executeForm.checkItemName" disabled />
        </el-form-item>
        <el-form-item label="检验医生">
          <el-input v-model="executeForm.checkDoctor" />
        </el-form-item>
        <el-form-item label="检验时间">
          <el-date-picker v-model="executeForm.checkTime" type="datetime" />
        </el-form-item>
        <el-form-item label="检验结果">
          <el-input type="textarea" v-model="executeForm.result" :rows="4" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="executeVisible = false">取消</el-button>
        <el-button type="primary" @click="submitExecute">保存结果</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import service from '@/utils/request'

// 搜索条件
const search = reactive({
  medicalId: '',
  patientName: '',
  status: ''
})

// 数据列表
const checkList = ref([])
const detail = ref({})
const executeForm = ref({})

// 对话框状态
const detailVisible = ref(false)
const executeVisible = ref(false)

// 获取列表数据
const fetchList = async () => {
    const res = await service.get('/checkapply/list', { params: search })
    checkList.value = res.data
}

// 查看详情
const viewDetail = (row) => {
  detail.value = { ...row }
  detailVisible.value = true
}

// 执行检验
const executeCheck = () => {
  executeForm.value = {
    checkApplyId: detail.value.id,
    checkItemName: detail.value.checkItemName,
    checkDoctor: '',
    checkTime: new Date(),
    result: ''
  }
  executeVisible.value = true
}

// 提交检验结果
const submitExecute = async () => {
  try {
    await service.post('/checkapply/execute', executeForm.value)
    ElMessage.success('检验结果已提交')
    executeVisible.value = false
    detailVisible.value = false
    fetchList()
  } catch (error) {
    ElMessage.error('提交失败')
  }
}

onMounted(() => {
  fetchList()
})
</script>