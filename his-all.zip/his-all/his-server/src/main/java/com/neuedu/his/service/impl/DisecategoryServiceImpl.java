package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Disecategory;
import com.neuedu.his.service.DisecategoryService;
import com.neuedu.his.mapper.DisecategoryMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【disecategory】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class DisecategoryServiceImpl extends ServiceImpl<DisecategoryMapper, Disecategory>
    implements DisecategoryService{

}




