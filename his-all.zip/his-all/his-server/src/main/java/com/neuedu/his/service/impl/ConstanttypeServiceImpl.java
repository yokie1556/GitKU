package com.neuedu.his.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.neuedu.his.po.Constanttype;
import com.neuedu.his.service.ConstanttypeService;
import com.neuedu.his.mapper.ConstanttypeMapper;
import org.springframework.stereotype.Service;

/**
* @author Superior
* @description 针对表【constanttype】的数据库操作Service实现
* @createDate 2025-06-25 18:42:33
*/
@Service
public class ConstanttypeServiceImpl extends ServiceImpl<ConstanttypeMapper, Constanttype>
    implements ConstanttypeService{

}




